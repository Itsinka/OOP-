public class Magazine extends Publication{
    private String publicationDate;
    private int volume;
    private String subject;

    Magazine(String magazineName, String genre, String author, int year,
             int volume, String subject, String publicationDate){
        super(magazineName, genre, author, year);
        setSubject(subject);
        setVolume(volume);
        setPublicationDate(publicationDate);
    }
    public String getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }
    public int getVolume() {
        return volume;
    }
    public void setVolume(int volume) {
        volume = volume;
    }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String printText() {
        return getClass().getName() + "{" +
                "magazineName='" + publicationName + '\'' +
                ", genre='" + genre + '\'' +
                ", author='" + author + '\'' +
                ", year=" + year +
                ", volume=" + volume +
                ", subject=" + subject +
                ", publicationDate=" + publicationDate +
                '}';
    }

}
