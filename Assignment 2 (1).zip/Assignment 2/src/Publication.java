abstract class Publication implements InfoPrint{
    protected String publicationName;
    protected String genre;
    protected String author;
    protected int year;

    Publication(String publicationName, String genre, String author, int year){
        setPublicationName(publicationName);
        setGenre(genre);
        setAuthor(author);
        setYear(year);
    }

    public String getPublicationName() {
        return publicationName;
    }

    public void setPublicationName(String publicationName) {
        this.publicationName = publicationName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }


}
