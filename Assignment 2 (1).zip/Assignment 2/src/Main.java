public class Main {
    /**
    * Main method where your program starts to work. First of all, it is displayed a menu.
    * We created the object of Menu class and called the method go()
     */
    public static void main(String[] args) {
        Menu menu1 = new Menu();
        menu1.go();


    }
}