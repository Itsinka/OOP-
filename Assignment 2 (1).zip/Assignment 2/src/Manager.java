import java.util.ArrayList;

/**
 * Class Manager with methods
 */
public class Manager {
    // We initialize the variables PASSWORD and USERNAME as constants
    final String PASSWORD = "123456789";
    final String USERNAME = "manager";


    // We initialized a boolean variable as false, which we convert to true, when a user is logged-in.
    private Boolean isLoggedIn = false;
    // We declare an empty array of objects
    private ArrayList<Book> books  =  new ArrayList<>();
    private ArrayList<Magazine> magazines  =  new ArrayList<>();
    //Book[] books;
    Manager(){
    }

    public Boolean getLoggedIn() {
        return isLoggedIn;
    }

    public void loggedInFirst(){
        System.out.println("You have to log in first!");
    }

    /**
     * The method logIn to check password and username, if they coincide with constants, so to let user log in
     */
    public boolean logIn(String username, String password){
        if(USERNAME.equals(username) && PASSWORD.equals(password)){
            isLoggedIn = true;
        }
        return isLoggedIn;
    }

    public void logOut(){
        isLoggedIn = false;
    }

    public boolean checkLogIn(){
        if(isLoggedIn) {
            return true;
        }
        loggedInFirst();
        return false;
    }
    public void addPublication(Book book) {
        if(checkLogIn()) {
            books.add(book);
        }
    }

    public void addPublication(Magazine magazine) {
        if(checkLogIn()) {
            magazines.add(magazine);
        }
    }

    /**
     * Method removeBook iterate through all elements in the array of objects and
     * if id coincides with inputted it, we shift the array by one element
     */
    public void removeBook(int bookId){
        //
        if(isLoggedIn && books != null) {
            books.remove(bookId);
            printAllBooks();
        }
        else if (books == null){
            System.out.println("There is no book with such id. You have to add books first!");
        }
        else {
            loggedInFirst();
        }
    }

    /**
     * method printAllBooks display all books
     */
    public void printAllBooks(){
        if(checkLogIn()) {
            for (int i = 0; i < books.size(); i++) {
                System.out.println(i + " book Name" + books.get(i).printText());
            }
        }
    }

    public void printAllMagazines(){
        if(checkLogIn()) {
            for (int i = 0; i < magazines.size(); i++) {
                System.out.println(i + " book Name" + magazines.get(i).printText());
            }
        }
    }

}
