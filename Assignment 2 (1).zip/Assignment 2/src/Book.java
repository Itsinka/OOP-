public class Book extends Publication{
    Book(String bookName, String genre, String author, int year){
        super(bookName, genre, author, year);
    }

    public String printText() {
        return getClass().getName() + "{" +
                "bookName='" + publicationName + '\'' +
                ", genre='" + genre + '\'' +
                ", author='" + author + '\'' +
                ", year=" + year +
                '}';
    }


}

