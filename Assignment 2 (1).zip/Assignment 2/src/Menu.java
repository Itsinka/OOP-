import java.util.ArrayList;
import java.util.Scanner;

public class Menu {

    /**
     * variable choice for switch-case menu
     */
    public int choice;


    /**
     * Method go() contains switch-case structure with call all methods
     */
    public void go() {
        //Display the message toe greet a manager
        System.out.println("Hello, manager! You have the following available functions:");
        //Create the object manager of Manager class
        Manager manager = new Manager();

        while(true) {
            menu(); // call the method menu() to show available functions
            System.out.println("Enter Your menu choice [1 - 8]: ");
            Scanner sc = new Scanner(System.in); // Create the object of the class Scanner to be able to input data
            choice = sc.nextInt(); // Input the variable choice from keyboard

            switch(choice){
                case 1: { // case to log in
                    // Input a username and password
                    System.out.println("Insert a username");
                    String username = sc.next();
                    System.out.println("Insert a password");
                    String password = sc.next();
                    // Condition if checks that a user was logged in.
                    // If the return value of the method lofIn is true, it means that use was logged in
                    if(manager.logIn(username, password)){
                        System.out.println("You have logged in successfully!");
                    }
                    //In another case warning message
                    else{
                        System.out.println("You have inserted wrong username or password!");
                    };
                    break;
                }
                case 2: {
                }
                case 3: {
                    if(manager.checkLogIn())
                    {
                        printMenuAdd(manager, choice);
                    }
                    break;
                }

                case 4: {// case 3 to remove book from the array of objects by id
                    if(manager.checkLogIn()) {
                        System.out.println("Enter book which you want to remove: book id");
                        int bookId = sc.nextInt();
                        manager.removeBook(bookId);
                    }
                    break;
                }
                case 5: {
                    if(manager.checkLogIn()) {
                        manager.printAllBooks();
                    }
                    break;
                }
                case 6: {
                    if(manager.checkLogIn()) {
                        manager.printAllMagazines();
                    }
                    break;
                }
                case 7:{
                    manager.logOut();
                    System.out.println("You have logged out successfully!");
                    break;
                }
                case 8: {
                    System.exit(0);
                }
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }

    public void menu(){
        System.out.println("1.\tto log in");
        System.out.println("2.\tto add a new book");
        System.out.println("3.\tto add a new magazine");
        System.out.println("4.\tto remove a book");
        System.out.println("5.\tto print all available books");
        System.out.println("6.\tto print all available magazines");
        System.out.println("7.\tto log out");
        System.out.println("8.\tto finish the program");
    }
    public void printMenuAdd(Manager manager, int choice){
        String item;
        if (choice == 2){
            item = "book";
        }
        else
            item = "magazine";

        System.out.println("How many " + item + "s do you want to add?");
        Scanner sc = new Scanner(System.in);
        int numberBooks = sc.nextInt();
        for (int i = 0; i < numberBooks; i++) {
            // We input fields of the book for each object in the array
            System.out.println("Enter name of "+ i + " " + item + ": " + item + " name");
            sc.nextLine();
            String bookName = sc.nextLine();
            System.out.println("Enter genre of "+ i + " " + item + ": genre");
            String genre = sc.next();
            System.out.println("Enter author of "+ i + " " + item + ": author");
            String author = sc.next();
            System.out.println("Enter year of "+ i + " " + item + ": year");
            int year = sc.nextInt();
            // We add book
            if (choice == 2){
                Book book = new Book(bookName, genre, author, year);
                manager.addPublication(book);}
            else
            {
                System.out.println("Enter year of "+ i + " " + item + ": volume");
                int volume = sc.nextInt();
                System.out.println("Enter year of "+ i + " " + item + ": subject");
                String subject = sc.next();
                System.out.println("Enter year of "+ i + " " + item + ": publicationDate");
                String publicationDate = sc.next();
                Magazine magazine = new Magazine(bookName, genre, author,
                        year, volume, subject, publicationDate);
                manager.addPublication(magazine);
        }
        }

    }
}
