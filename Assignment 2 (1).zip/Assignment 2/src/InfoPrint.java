interface InfoPrint {
    public String printText();
}
